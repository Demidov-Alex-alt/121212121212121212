def all_divisors(number):
    divisors = []
    for i in range(1, int(number ** 0.5) + 1):
        if number % i == 0:
            divisors.append(i)
            if i != number // i:
                divisors.append(number // i)
    divisors.sort()
    return divisors


# Пример

number1 = 23436
number2 = 190187200
number3 = 380457890232

divisors1 = all_divisors(number1)
divisors2 = all_divisors(number2)
divisors3 = all_divisors(number3)

print(divisors1)
print(divisors2)
print(divisors3)
