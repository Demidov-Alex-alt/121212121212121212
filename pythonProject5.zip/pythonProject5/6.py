def is_magic_square(matrix):
    n = len(matrix)

    target_sum = n * (n ** 2 + 1) // 2

    for row in matrix:
        if sum(row) != target_sum:
            return False
    for col in range(n):
        if sum(matrix[row][col] for row in range(n)) != target_sum:
            return False
    if sum(matrix[i][i] for i in range(n)) != target_sum:
        return False

    if sum(matrix[i][n - 1 - i] for i in range(n)) != target_sum:
        return False

    return True


# пример

matrix = [[2, 7, 6],
          [9, 5, 1],
          [4, 3, 8]]

if is_magic_square(matrix):
    print("Матрица является магическим квадратом")
else:
    print("Матрица не является магическим квадратом")
